// Copyright June Rhodes 2024. All Rights Reserved.

#pragma once

/********************************************************************
 * Provided to allow EOS_BUILD_PLATFORM_NAME to be defined even for
 * platforms that do not require it when using eos_platform_prereqs.h
 ********************************************************************/